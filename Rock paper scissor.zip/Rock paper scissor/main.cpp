
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main() {
    srand(time(0)); // Seed the random number generator

    string choices[] = {"Rock", "Paper", "Scissor"};
    int computerChoice = rand() % 3; // Generate a random number between 0 and 2
    int userChoice;

    cout << "Welcome to Rock Paper Scissor!" << endl;
    cout << "Enter your choice:" << endl;
    cout << "0 - Rock" << endl;
    cout << "1 - Paper" << endl;
    cout << "2 - Scissor" << endl;
    cin >> userChoice;

    cout << "Computer chose: " << choices[computerChoice] << endl;
    cout << "You chose: " << choices[userChoice] << endl;

    if (userChoice == computerChoice) {
        cout << "It's a tie!" << endl;
    } else if ((userChoice == 0 && computerChoice == 2) || (userChoice == 1 && computerChoice == 0) || (userChoice == 2 && computerChoice == 1)) {
        cout << "You win!" << endl;
    } else {
        cout << "Computer wins!" << endl;
    }

    return 0;
}



